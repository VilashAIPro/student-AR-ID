import React, { useState } from 'react';
import { Play, Camera, X } from 'lucide-react';

function App() {
  const [isScanning, setIsScanning] = useState(false);

  const handleScan = () => {
    window.open('https://zap.works/designer/', '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      {/* Hero Section */}
      <div className="container mx-auto px-4 pt-20 pb-32">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Student AR ID
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
                Next-Gen Identification
              </span>
            </h1>
            <p className="text-lg text-gray-300 mb-8">
              Experience the future of student identification with our cutting-edge AR technology.
            </p>
            <button
              onClick={handleScan}
              className="group inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-4 rounded-full font-semibold hover:scale-105 transition-all duration-300 ease-in-out shadow-lg"
            >
              <Play className="group-hover:animate-pulse" />
              Try AR Experience
            </button>
          </div>
          <div className="flex-1">
            <img
              src="https://images.unsplash.com/photo-1557200134-90327ee9fafa?auto=format&fit=crop&w=800&q=80"
              alt="AR Visualization"
              className="rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;